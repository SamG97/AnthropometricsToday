--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.2
-- Dumped by pg_dump version 10.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.students_pre_1897 DROP CONSTRAINT pre1897studentkey;
ALTER TABLE ONLY public.students_post_1897 DROP CONSTRAINT post1897studentkey;
ALTER TABLE ONLY public.generatedpeople DROP CONSTRAINT generatedpeoplestudentkey;
ALTER TABLE public.students_pre_1897 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.students_post_1897 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.generatedpeople ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.students_pre_1897_id_seq;
DROP TABLE public.students_pre_1897;
DROP SEQUENCE public.students_post_1897_id_seq;
DROP TABLE public.students_post_1897;
DROP SEQUENCE public.generatedpeople_id_seq;
DROP TABLE public.generatedpeople;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: generatedpeople; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE generatedpeople (
    "DoB_month" integer,
    "DoB_day" integer,
    "DoB_year" integer,
    "Age" integer,
    "Name" character varying(100),
    "College" character varying(20),
    "Sex" character varying(20),
    "Eye_Colour" character varying(20),
    "Hair_Colour" character varying(20),
    "Head_length" real,
    "Face_breadth" real,
    "Face_iobreadth" real,
    id integer NOT NULL
);


ALTER TABLE generatedpeople OWNER TO postgres;

--
-- Name: generatedpeople_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE generatedpeople_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generatedpeople_id_seq OWNER TO postgres;

--
-- Name: generatedpeople_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE generatedpeople_id_seq OWNED BY generatedpeople.id;


--
-- Name: students_post_1897; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE students_post_1897 (
    "DM_month" integer,
    "DM_day" integer,
    "DM_year" integer,
    "Name" character varying(100),
    "College" character varying(20),
    "Age" integer,
    "Birthplace1" character varying(100),
    "Birthplace2" character varying(100),
    "Father_origin" character varying(100),
    "Mother_origin" character varying(100),
    "Skin" integer,
    "Hair_colour" real,
    "Hair_type" integer,
    "Eyes" integer,
    "Face_type" integer,
    "Cheekbones" integer,
    "Ears" real,
    "Lobes" integer,
    "Head_length" integer,
    "Head_breadth" integer,
    "Head_height" integer,
    "Nose_length" integer,
    "Nose_breadth" integer,
    "Nose_profile" character varying(100),
    "Face_length" integer,
    "Face_upper" integer,
    "Face_breadth" integer,
    "Face_iobreadth" integer,
    "Face_bibreadth" integer,
    "Height_feet" integer,
    "Height_inches" integer,
    "Height_tenths" integer,
    "True_feet" integer,
    "True_inches" integer,
    "True_tenths" integer,
    "Span_ft" integer,
    "Span_in" integer,
    "Span_tenths" integer,
    "Weight_stone" integer,
    "Weight_lbs" character varying(20),
    "Weight_oz (rare)" real,
    "Breathing Power" integer,
    "Pull_archer" integer,
    "Squeeze_right" integer,
    "Squeeze_left" integer,
    "Eye_right" integer,
    "Eye_left" integer,
    "Colour_sense" character varying(10),
    "Ceph_index_1" real,
    "Ceph_index_2" real,
    "Facial_index" real,
    "Nasal_index" real,
    "Upperfacial_index" real,
    "JOL" real,
    "BL" real,
    id integer NOT NULL
);


ALTER TABLE students_post_1897 OWNER TO postgres;

--
-- Name: students_post_1897_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE students_post_1897_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE students_post_1897_id_seq OWNER TO postgres;

--
-- Name: students_post_1897_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE students_post_1897_id_seq OWNED BY students_post_1897.id;


--
-- Name: students_pre_1897; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE students_pre_1897 (
    "Name" character varying(100),
    "College" character varying(30),
    "Birthplace1" character varying(100),
    "Birthplace2" character varying(100),
    "DB_month" integer,
    "DB_day" integer,
    "DB_year" integer,
    "Origin1" character varying(100),
    "Origin2" character varying(100),
    "Age" integer,
    "DM_month" integer,
    "DM_day" integer,
    "DM_year" integer,
    "Initials" character varying(20),
    "Eyes" integer,
    "Eye_right" integer,
    "Eye_left" integer,
    "Pull_archer" integer,
    "Squeeze_right" integer,
    "Squeeze_left" integer,
    "Breathing Power" integer,
    "Head (annotation in box)" real,
    "Head_breadth" real,
    "Head_length" real,
    "Head_brow" real,
    "Height_feet" real,
    "Height_inches" integer,
    "Height_tenths" integer,
    "Heel_inches" integer,
    "Heel_tenths" integer,
    "True_feet" integer,
    "True_inches" integer,
    "True_tenths" integer,
    "Weight_stone" integer,
    "Weight_lbs" real,
    "Weight_oz (rare)" real,
    "Span_ft" real,
    "Span_in" real,
    "Span_tenths" real,
    id integer NOT NULL
);


ALTER TABLE students_pre_1897 OWNER TO postgres;

--
-- Name: students_pre_1897_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE students_pre_1897_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE students_pre_1897_id_seq OWNER TO postgres;

--
-- Name: students_pre_1897_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE students_pre_1897_id_seq OWNED BY students_pre_1897.id;


--
-- Name: generatedpeople id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generatedpeople ALTER COLUMN id SET DEFAULT nextval('generatedpeople_id_seq'::regclass);


--
-- Name: students_post_1897 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY students_post_1897 ALTER COLUMN id SET DEFAULT nextval('students_post_1897_id_seq'::regclass);


--
-- Name: students_pre_1897 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY students_pre_1897 ALTER COLUMN id SET DEFAULT nextval('students_pre_1897_id_seq'::regclass);


--
-- Data for Name: generatedpeople; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY generatedpeople ("DoB_month", "DoB_day", "DoB_year", "Age", "Name", "College", "Sex", "Eye_Colour", "Hair_Colour", "Head_length", "Face_breadth", "Face_iobreadth", id) FROM stdin;
\.
COPY generatedpeople ("DoB_month", "DoB_day", "DoB_year", "Age", "Name", "College", "Sex", "Eye_Colour", "Hair_Colour", "Head_length", "Face_breadth", "Face_iobreadth", id) FROM '$$PATH$$/2819.dat';

--
-- Data for Name: students_post_1897; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY students_post_1897 ("DM_month", "DM_day", "DM_year", "Name", "College", "Age", "Birthplace1", "Birthplace2", "Father_origin", "Mother_origin", "Skin", "Hair_colour", "Hair_type", "Eyes", "Face_type", "Cheekbones", "Ears", "Lobes", "Head_length", "Head_breadth", "Head_height", "Nose_length", "Nose_breadth", "Nose_profile", "Face_length", "Face_upper", "Face_breadth", "Face_iobreadth", "Face_bibreadth", "Height_feet", "Height_inches", "Height_tenths", "True_feet", "True_inches", "True_tenths", "Span_ft", "Span_in", "Span_tenths", "Weight_stone", "Weight_lbs", "Weight_oz (rare)", "Breathing Power", "Pull_archer", "Squeeze_right", "Squeeze_left", "Eye_right", "Eye_left", "Colour_sense", "Ceph_index_1", "Ceph_index_2", "Facial_index", "Nasal_index", "Upperfacial_index", "JOL", "BL", id) FROM stdin;
\.
COPY students_post_1897 ("DM_month", "DM_day", "DM_year", "Name", "College", "Age", "Birthplace1", "Birthplace2", "Father_origin", "Mother_origin", "Skin", "Hair_colour", "Hair_type", "Eyes", "Face_type", "Cheekbones", "Ears", "Lobes", "Head_length", "Head_breadth", "Head_height", "Nose_length", "Nose_breadth", "Nose_profile", "Face_length", "Face_upper", "Face_breadth", "Face_iobreadth", "Face_bibreadth", "Height_feet", "Height_inches", "Height_tenths", "True_feet", "True_inches", "True_tenths", "Span_ft", "Span_in", "Span_tenths", "Weight_stone", "Weight_lbs", "Weight_oz (rare)", "Breathing Power", "Pull_archer", "Squeeze_right", "Squeeze_left", "Eye_right", "Eye_left", "Colour_sense", "Ceph_index_1", "Ceph_index_2", "Facial_index", "Nasal_index", "Upperfacial_index", "JOL", "BL", id) FROM '$$PATH$$/2814.dat';

--
-- Data for Name: students_pre_1897; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY students_pre_1897 ("Name", "College", "Birthplace1", "Birthplace2", "DB_month", "DB_day", "DB_year", "Origin1", "Origin2", "Age", "DM_month", "DM_day", "DM_year", "Initials", "Eyes", "Eye_right", "Eye_left", "Pull_archer", "Squeeze_right", "Squeeze_left", "Breathing Power", "Head (annotation in box)", "Head_breadth", "Head_length", "Head_brow", "Height_feet", "Height_inches", "Height_tenths", "Heel_inches", "Heel_tenths", "True_feet", "True_inches", "True_tenths", "Weight_stone", "Weight_lbs", "Weight_oz (rare)", "Span_ft", "Span_in", "Span_tenths", id) FROM stdin;
\.
COPY students_pre_1897 ("Name", "College", "Birthplace1", "Birthplace2", "DB_month", "DB_day", "DB_year", "Origin1", "Origin2", "Age", "DM_month", "DM_day", "DM_year", "Initials", "Eyes", "Eye_right", "Eye_left", "Pull_archer", "Squeeze_right", "Squeeze_left", "Breathing Power", "Head (annotation in box)", "Head_breadth", "Head_length", "Head_brow", "Height_feet", "Height_inches", "Height_tenths", "Heel_inches", "Heel_tenths", "True_feet", "True_inches", "True_tenths", "Weight_stone", "Weight_lbs", "Weight_oz (rare)", "Span_ft", "Span_in", "Span_tenths", id) FROM '$$PATH$$/2817.dat';

--
-- Name: generatedpeople_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('generatedpeople_id_seq', 10000, true);


--
-- Name: students_post_1897_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('students_post_1897_id_seq', 3, true);


--
-- Name: students_pre_1897_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('students_pre_1897_id_seq', 3, true);


--
-- Name: generatedpeople generatedpeoplestudentkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generatedpeople
    ADD CONSTRAINT generatedpeoplestudentkey PRIMARY KEY (id);


--
-- Name: students_post_1897 post1897studentkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY students_post_1897
    ADD CONSTRAINT post1897studentkey PRIMARY KEY (id);


--
-- Name: students_pre_1897 pre1897studentkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY students_pre_1897
    ADD CONSTRAINT pre1897studentkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

